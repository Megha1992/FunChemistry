package com.example.funchem;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class PlayActivity extends Activity {
	TextView tvRes, tvQuestion;
	RadioButton rb1, rb2, rb3, rb4;
	Button next;
	int answer;
	static int i = 0, score=0;
	MediaPlayer correct, wrong;
	String questions[] = {
			"C + ? => CO2",
			"The nucleus of an atom consists of",
			"The number of moles of solute present in 1 kg of a solvent is called its",
			"The most electronegative element among the following is",
			"The metal used to recover copper from a solution of copper sulphate is",
			"The metallurgical process in which a metal is obtained in a fused state is called",
			"The main buffer system of the human blood is",
			"The monomer of polythene is",
			"The oil used in the froth floatation process is" };
	int answers[] = { 1, 3, 1, 3, 4, 1, 1, 2, 4 };
	// List<String> answerSet = new ArrayList<String>();
	String optionSet[][] = {
			{ "O2", "CO2", "H2O", "CL2" },
			{ "electrons and neutrons", "electrons and protons",
					"protons and neutrons", "all" },
			{ "Molality", "molarity", "normality", "None of the above" },
			{ "Sodium", "bromine", "Fluorine", "oxygen" },
			{ "Na", "Ag", "Hg", "Fe" },
			{ "Smelting", "roasting", "calcination", "froth floatation" },
			{ "H2CO3 – HCO3", "H2CO3 – CO32-", "CH3COOH–CH3COO-",
					"NH2CONH2–NH2CONH+" },
			{ "vinyl chloride", "Ethylene", "ethyl alcohol",
					"None of the above" },
			{ "coconut oil", "olive oil", "kerosene oil", "pine oil" }

	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.play);
		answer = 3;
		correct = MediaPlayer.create(PlayActivity.this, R.raw.sms);
		wrong = MediaPlayer.create(PlayActivity.this, R.raw.ding);
		rb1 = (RadioButton) findViewById(R.id.radioButton1);
		rb2 = (RadioButton) findViewById(R.id.radioButton2);
		rb3 = (RadioButton) findViewById(R.id.radioButton3);
		rb4 = (RadioButton) findViewById(R.id.radioButton4);
		tvRes = (TextView) findViewById(R.id.tvResult);
		tvQuestion = (TextView) findViewById(R.id.tvquestion);
		next = (Button) findViewById(R.id.bnext);
		
		rb1.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				if (answer == 1) {
					tvRes.setText("Correct");
					score++;
					correct.start();
				} else {
					tvRes.setText("Wrong");
					wrong.start();
				}

			}
		});
		rb2.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (answer == 2) {
					tvRes.setText("Correct");
					correct.start();
				} else {
					tvRes.setText("Wrong");
					wrong.start();
				}
			}
		});
		rb3.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (answer == 3) {
					tvRes.setText("Correct");
					correct.start();
				} else {
					tvRes.setText("Wrong");
					wrong.start();
				}
			}
		});
		rb4.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				if (answer == 4) {
					tvRes.setText("Correct");
					correct.start();
				} else {
					tvRes.setText("Wrong");
					wrong.start();
				}
			}
		});
		next.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				boolean isFinished = false;
				try {
				
				tvQuestion.setText(questions[i]);
				answer = answers[i];
				String[][] options = optionSet;
				rb1.setText(options[i][0]);
				rb2.setText(options[i][1]);
				rb3.setText(options[i][2]);
				rb4.setText(options[i][3]);
				rb1.setChecked(false);
				rb2.setChecked(false);
				rb3.setChecked(false);
				rb4.setChecked(false);
				tvRes.setText("Select Answer");
				i++;
				} catch (Exception e) {
					isFinished = true;
				}
				finally{
					if(isFinished){
						tvRes.setText("Finished!!");
						try {
							wait(200);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Intent openMainActivity = new Intent("com.example.funchem.MAINACTIVITY");
						startActivity(openMainActivity);
						
					}
				}
			}
		});
	}

	

}
